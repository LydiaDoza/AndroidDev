package lsdoza.week3part2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import android.text.TextWatcher;
import java.text.NumberFormat;


public class MainActivity extends AppCompatActivity {
    private blackjack BlackJack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BlackJack = new blackjack();
        setContentView(R.layout.activity_main);

        TextView card1 = (TextView)findViewById(R.id.card1);
        TextView card2 = (TextView)findViewById(R.id.card2);
        TextView card3 = (TextView)findViewById(R.id.card3);
        TextView total = (TextView)findViewById(R.id.total);

        card1.setText(Integer.toString(BlackJack.GetCard1()));
        card2.setText(Integer.toString(BlackJack.GetCard2()));
        total.setText(Integer.toString(BlackJack.GetTotal()));

        final Button drawButton = (Button) findViewById(R.id.drawButton);


    }

    public void DrawCard3(View v){
        if (BlackJack.GetTotal() < 15){
            BlackJack.DrawCard3();
            TextView card3 = (TextView)findViewById(R.id.card3);
            TextView total = (TextView)findViewById(R.id.total);
            card3.setText(Integer.toString(BlackJack.GetCard3()));
            total.setText(Integer.toString(BlackJack.GetTotal()));
        }
    }
}
